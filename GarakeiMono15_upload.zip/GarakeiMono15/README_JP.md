# GarakeiMono15 0.1.1

iPhone 7（iOS 15 / Dopamine rootless）で、目が疲れにくい見た目にする tweak です。
パッケージ: com.tori.garakeimono15 / rootless / arm64 / 依存: ElleKit

## 0.1.1 の変更点（0.1.0 の実機ログを受けた直し）

0.1.0 の実機ログで確定したこと:

| 項目 | 結果 |
|---|---|
| 本体の動作 | 正常（DYLIB_LOADED、設定連動 OK、Safe Mode なし） |
| まぶしさ軽減（ホワイトポイント） | **動作確認済み**。`setReduceWhitePointEnabled:` が実在し、呼び出し成功＋読み戻し一致。0.1.1 でもそのまま維持 |
| 白黒（グレースケール） | **効かなかった**。AXSettings はあるのに `setGrayscaleEnabled:` など候補3つ全部が「無い」（setter_not_found）。白黒の入口はこの名前ではない |
| 太い文字 | 0.1.0 では未試行 |

0.1.1 でやったこと:

| # | 中身 |
|---|---|
| 1 | **本命の直し：画面フィルタ方式**。白黒オンの間、SpringBoard の全ウィンドウのレイヤーに CAFilter（`colorSaturation`、inputAmount=0.0）を掛けて白黒表示にする。アクセシビリティ設定の入口が無くても効く通り道。オフで外れる。結果はログの `FILTER_APPLY` 行で分かる。ウィンドウ単位のみ（個別ビューには付けない）ので重くなりにくい。適用は設定変更のたび＋SpringBoard 起動完了後にもう1回（後から出たウィンドウ用） |
| 2 | **診断ダンプ（白黒オン時に1回だけ）**。AXSettings のメソッドのうち gray / grey / filter / color / mono / saturat を含む名前を全部ログに出す（`METHOD_DUMP`）。あわせて `com.apple.Accessibility` の候補キー（ColorFiltersEnabled 等18個）の現在値を読み取り専用で出す（`PREF_DUMP`、値は変えない） |
| 3 | **白黒の別ルート試行**。AXSettings の追加候補セッター（`setColorFilterEnabled:`、`setDisplayFilterEnabled:` 等）を実在確認してから呼ぶ＋KVC（`setValue:forKey:`）の候補キーも試す。全部 @try/@catch、結果と読み戻しをログに残す |
| 4 | バージョンを 0.1.1 に上げた（control／ログの version 表示／ワークフローの検査・成果物名・.deb 名） |

## 0.1.0 から入っている物

| 部分 | 中身 |
|---|---|
| 設定画面 | 全体のスイッチ、白黒スイッチ、まぶしさ軽減スイッチ、ガラケー風スイッチ、今すぐ適用ボタン、ログを見る／消すボタン。選択UIは全部ボタン式（PSButtonCell）で、この実機で落ちる一覧選択（PSLinkListCell＋PSListItemsController）は使っていません |
| ログ | /var/mobile/Library/Logs/GarakeiMono15.log。ファイルは無い時だけ作って追記し、行頭にプロセス名、段階ログ（DYLIB_LOADED → PREFS → APPLY_START → CLASS/INSTANCE/SETTER → CALL/READBACK → APPLY_RESULT、0.1.1 から DIAG_DUMP / METHOD_DUMP / PREF_DUMP / KVC_TRY / FILTER_APPLY）を残します |
| 安全装置 | 全段 @try/@catch、例外が5回たまると全機能が止まる失敗ブレーキ付き。SpringBoard の中で重い処理や危険な初期化は入れていません |

## フィルタが SpringBoard だけの理由

フィルタ対象は SpringBoard のみです。0.1.1 の画面フィルタ方式は
SpringBoard のウィンドウ（ホーム画面・ロック画面・ステータスバー等）に
掛ける形で、まずホーム画面が白黒になるかを実機で確かめるのが目的です。
全アプリの画面そのものは各アプリのウィンドウなので、この方式では
まだ白黒になりません。全アプリ展開は、フィルタ方式が実機で効くことが
確認できてから次の段階で検討します。

## 正直な線引き（届く範囲）

- **届く**: システム全体の見た目の変更までです。白黒化、まぶしさ軽減、
  大きい／濃い文字、ホーム画面の見た目のような、iOS 自身が持っている
  見た目の仕組み＋SpringBoard 内の画面フィルタで届く範囲になります。
- **届かない**: 各アプリの中身の並び（レイアウト）自体をガラケー風に
  作り替えることは、そのアプリの作りの上から外側の tweak ではできません。
- **未確認**: 画面フィルタ方式（CAFilter の `colorSaturation`）がこの
  iOS 15.8 系の SpringBoard で受理されるかは実機未確認です。受理され
  なければログの `FILTER_APPLY` 行に理由が残ります。診断ダンプ
  （METHOD_DUMP / PREF_DUMP）が、本命が効かなかった場合の次の
  直し方の材料になります。

## 実機テスト（0.1.1）

| # | 手順 | 合格の目印 |
|---|---|---|
| A | Sileo で入れてリスプリング、いつも通り使う | Safe Mode に入らない |
| B | 設定アプリを開く | 「GarakeiMono15（目に優しい白黒）」が出て、画面が開く |
| C | 設定で「白黒にする」をオンにして「今すぐ適用」、ホーム画面に戻る | **ホーム画面が白黒になれば 0.1.1 の本命は成功** |
| D | 「白黒にする」をオフに戻して「今すぐ適用」 | 色が元に戻る |
| E | ログを送る | /var/mobile/Library/Logs/GarakeiMono15.log（設定の「ログを見る」でも確認可）。特に FILTER_APPLY / METHOD_DUMP / PREF_DUMP の行が次の判断材料 |

まぶしさ軽減は 0.1.0 で動作確認済みなので、C の白黒が今回の主役です。
うまくいかない時はログファイルを送ってください。

## 次の段階（実機確認の後）

1. C の結果と FILTER_APPLY／診断ダンプで白黒の通り道を確定させる
2. 効いたら全アプリへの展開（注入範囲の拡大）を検討する
3. 大きい文字（文字サイズ）とホーム画面のガラケー風の見た目を足す
