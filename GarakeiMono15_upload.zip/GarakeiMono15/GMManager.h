#import <Foundation/Foundation.h>

// GarakeiMono15 manager:
// owns the diagnostic log, the prefs snapshot, the failure brake and
// the stage-1 "apply" machinery. Every feature path passes through
// the brake and writes stage lines to the log so a failure on the
// real device can be traced instead of guessed.
@interface GMManager : NSObject
+ (instancetype)shared;
- (void)setup;
- (void)reloadPrefs;
+ (BOOL)brakeOn;
@end

// Shared prefs / logging / brake helpers used by Tweak.x too.
void GMLoadPrefs(void);
void GMLog(NSString *format, ...);
void GMNoteException(NSString *where, id error);
void GMApplyAll(void);
