// GarakeiMono15 — entry point (0.1.1)
// iPhone 7 / iOS 15 / Dopamine (rootless).
// The filter plist injects this dylib into SpringBoard only for the
// skeleton stage: the stage-1 appearance settings are system-wide
// accessibility settings owned by SpringBoard-side processes, and
// widening injection to every app is only considered after the
// device test proves the grayscale call works (see README).
// Nothing heavy or risky is initialised here: the constructor only
// writes the first log lines, loads prefs and installs one hook.

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "GMManager.h"

@interface SpringBoard : UIApplication
@end

static void gmPrefsChanged(CFNotificationCenterRef center, void *observer,
                           CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[GMManager shared] reloadPrefs];
    });
}

%group GMSpringBoardGroup
%hook SpringBoard
- (void)applicationDidFinishLaunching:(UIApplication *)application {
    %orig;
    GMLog(@"SPRINGBOARD_LAUNCHED");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [[GMManager shared] setup];
    });
}
%end
%end

%ctor {
    @autoreleasepool {
        GMLog(@"DYLIB_LOADED version=0.1.1");
        GMLoadPrefs();
        GMLog(@"PREFS_LOADED at ctor");
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
            gmPrefsChanged, (__bridge CFStringRef)@"com.tori.garakeimono15.changed", NULL,
            CFNotificationSuspensionBehaviorDeliverImmediately);
        NSString *bid = [[NSBundle mainBundle] bundleIdentifier] ?: @"?";
        if ([bid isEqualToString:@"com.apple.springboard"]) {
            %init(GMSpringBoardGroup);
            GMLog(@"HOOKS_INSTALLED group=SpringBoard");
        } else {
            GMLog(@"SKIP not SpringBoard process=%@", bid);
        }
    }
}
