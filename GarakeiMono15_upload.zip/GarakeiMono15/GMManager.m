// GarakeiMono15 — core (0.1.0 skeleton + stage-1 entry)
//
// Stage 1 tries to switch iOS's own accessibility appearance
// settings (grayscale / reduce white point / bold text) from inside
// SpringBoard. Those settings live behind private Accessibility
// classes (AXSettings and friends) whose exact class, singleton and
// method names are NOT guaranteed on iOS 15.8, so nothing here is
// hard-coded on a guess:
//
//   - every candidate class / instance getter / setter / getter is
//     resolved at runtime with NSClassFromString / NSSelectorFromString,
//   - a setter is only ever called when the object really responds
//     to it (respondsToSelector:),
//   - every step (class found?, instance?, setter?, call, read-back)
//     is written to the log, so the device log itself proves which
//     names exist on this iOS and whether the call took effect.
//
// If a name does not exist, the feature simply does nothing and the
// log says why. All calls are wrapped in @try/@catch and counted by
// the failure brake: after 5 exceptions all feature activity stops
// until respring, so a broken path can never loop into Safe Mode.
// No heavy or risky initialisation lives in SpringBoard.

#import "GMManager.h"
#import <UIKit/UIKit.h>
#import <objc/message.h>
#import <objc/runtime.h>

NSString * const kGMPrefsID = @"com.tori.garakeimono15";
static NSString * const kGMVersion = @"0.1.0";

// ---------- prefs ----------
static BOOL prefEnabled = YES;
static BOOL prefGrayscale = NO;
static BOOL prefGlare = NO;
static BOOL prefGarakei = NO;

static id GMAppValue(NSString *key) {
    return (__bridge_transfer id)CFPreferencesCopyAppValue((__bridge CFStringRef)key,
                                                           (__bridge CFStringRef)kGMPrefsID);
}

void GMLoadPrefs(void) {
    @try {
        id v;
        v = GMAppValue(@"Enabled");           if (v) prefEnabled = [v boolValue];
        v = GMAppValue(@"GrayscaleEnabled");  if (v) prefGrayscale = [v boolValue];
        v = GMAppValue(@"ReduceGlareEnabled"); if (v) prefGlare = [v boolValue];
        v = GMAppValue(@"GarakeiStyleEnabled"); if (v) prefGarakei = [v boolValue];
        CFPreferencesAppSynchronize((__bridge CFStringRef)kGMPrefsID);
    } @catch (__unused id e) {}
}

// ---------- log ----------
// /var/mobile/Library/Logs/GarakeiMono15.log (fallback /var/tmp).
// The file is created ONLY when it does not exist and then appended
// to: creating it on every write from every process would truncate
// lines other processes already wrote (the Future15 0.2.x bug).
// Every line is prefixed with the process name.
static NSString *GMLogPath(void) {
    NSString *primary = @"/var/mobile/Library/Logs/GarakeiMono15.log";
    NSFileManager *fm = NSFileManager.defaultManager;
    if ([fm fileExistsAtPath:primary]) return primary;
    NSString *dir = @"/var/mobile/Library/Logs";
    if ([fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil] &&
        [fm createFileAtPath:primary contents:nil attributes:nil]) {
        return primary;
    }
    NSString *fallback = @"/var/tmp/GarakeiMono15.log";
    if (![fm fileExistsAtPath:fallback]) {
        [fm createFileAtPath:fallback contents:nil attributes:nil];
    }
    return fallback;
}

void GMLog(NSString *format, ...) {
    @try {
        va_list ap; va_start(ap, format);
        NSString *msg = [[NSString alloc] initWithFormat:format arguments:ap];
        va_end(ap);
        NSString *proc = [[NSProcessInfo processInfo] processName] ?: @"?";
        NSString *stamp = [NSDateFormatter localizedStringFromDate:[NSDate date]
                                                         dateStyle:NSDateFormatterNoStyle
                                                         timeStyle:NSDateFormatterMediumStyle];
        NSString *line = [NSString stringWithFormat:@"[%@][%@] %@\n", stamp, proc, msg];
        NSString *path = GMLogPath();
        NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:path];
        if (!fh) return;
        [fh seekToEndOfFile];
        [fh writeData:[line dataUsingEncoding:NSUTF8StringEncoding]];
        [fh synchronizeFile];
        [fh closeFile];
    } @catch (__unused id e) {}
}

// ---------- failure brake ----------
// After 5 exceptions anywhere in the manager the brake engages and
// every feature path stops until respring. It never auto-releases.
static NSInteger gExceptionCount = 0;
static BOOL gBrakeOn = NO;
static const NSInteger kGMBrakeThreshold = 5;

void GMNoteException(NSString *where, id error) {
    gExceptionCount++;
    GMLog(@"EXCEPTION %@: %@ (count=%ld)", where, error, (long)gExceptionCount);
    if (!gBrakeOn && gExceptionCount >= kGMBrakeThreshold) {
        gBrakeOn = YES;
        GMLog(@"BRAKE_ON exceptions reached %ld: all feature activity is stopped until respring", (long)gExceptionCount);
    }
}

// ---------- stage-1 apply machinery (runtime-resolved) ----------
static NSArray<NSString *> *GMClassCandidates(void) {
    return @[@"AXSettings", @"GAXSettings", @"_AXSettings", @"AXAccessibilitySettings"];
}
static NSArray<NSString *> *GMInstanceCandidates(void) {
    return @[@"sharedInstance", @"sharedSettings", @"shared", @"defaultSettings"];
}

// Tries one boolean accessibility setting. Returns nothing; the log
// carries the whole story (APPLY_START -> CLASS/INSTANCE/SETTER ->
// CALL/READBACK -> APPLY_RESULT).
static void GMApplyBoolFeature(NSString *feature,
                               NSArray<NSString *> *setterNames,
                               NSArray<NSString *> *getterNames,
                               BOOL desired) {
    GMLog(@"APPLY_START feature=%@ desired=%d", feature, desired);
    @try {
        Class cls = nil;
        NSString *clsName = nil;
        for (NSString *name in GMClassCandidates()) {
            Class c = NSClassFromString(name);
            GMLog(@"CLASS name=%@ found=%d", name, c != nil);
            if (c) { cls = c; clsName = name; break; }
        }
        if (!cls) {
            GMLog(@"APPLY_RESULT feature=%@ result=class_not_found", feature);
            return;
        }

        id instance = nil;
        NSString *instHow = nil;
        for (NSString *name in GMInstanceCandidates()) {
            SEL sel = NSSelectorFromString(name);
            if ([cls respondsToSelector:sel]) {
                @try {
                    instance = ((id (*)(id, SEL))objc_msgSend)((id)cls, sel);
                } @catch (__unused id e) { instance = nil; }
                GMLog(@"INSTANCE via=%@ ok=%d", name, instance != nil);
                if (instance) { instHow = name; break; }
            } else {
                GMLog(@"INSTANCE via=%@ missing=1", name);
            }
        }
        if (!instance) {
            @try {
                instance = [[cls alloc] init];
                instHow = @"alloc_init";
            } @catch (__unused id e) { instance = nil; }
            GMLog(@"INSTANCE via=alloc_init ok=%d", instance != nil);
        }
        if (!instance) {
            GMLog(@"APPLY_RESULT feature=%@ result=no_instance class=%@", feature, clsName);
            return;
        }

        SEL setter = NULL;
        NSString *setterName = nil;
        for (NSString *name in setterNames) {
            SEL sel = NSSelectorFromString(name);
            BOOL ok = [instance respondsToSelector:sel];
            GMLog(@"SETTER name=%@ responds=%d", name, ok);
            if (ok) { setter = sel; setterName = name; break; }
        }
        if (!setter) {
            GMLog(@"APPLY_RESULT feature=%@ result=setter_not_found class=%@ instance=%@", feature, clsName, instHow);
            return;
        }

        ((void (*)(id, SEL, BOOL))objc_msgSend)(instance, setter, desired);
        GMLog(@"CALL_OK feature=%@ setter=%@ value=%d", feature, setterName, desired);

        NSString *readback = @"unavailable";
        for (NSString *name in getterNames) {
            SEL sel = NSSelectorFromString(name);
            if ([instance respondsToSelector:sel]) {
                BOOL val = ((BOOL (*)(id, SEL))objc_msgSend)(instance, sel);
                readback = [NSString stringWithFormat:@"%@=%d", name, val];
                break;
            }
        }
        GMLog(@"READBACK feature=%@ %@", feature, readback);
        GMLog(@"APPLY_RESULT feature=%@ result=called setter=%@ readback=%@", feature, setterName, readback);
    } @catch (id e) {
        GMNoteException([NSString stringWithFormat:@"apply:%@", feature], e);
        GMLog(@"APPLY_RESULT feature=%@ result=exception", feature);
    }
}

// Tracks what this process actually switched on, so an OFF is only
// sent for something we turned on (never touching settings the user
// set by hand in the Accessibility menu).
static BOOL gmGrayscaleApplied = NO;
static BOOL gmGlareApplied = NO;
static BOOL gmGarakeiApplied = NO;

static void GMApplyOne(NSString *feature,
                       NSArray<NSString *> *setters,
                       NSArray<NSString *> *getters,
                       BOOL wantOn, BOOL *appliedFlag) {
    if (wantOn) {
        GMApplyBoolFeature(feature, setters, getters, YES);
        *appliedFlag = YES;
    } else if (*appliedFlag) {
        GMApplyBoolFeature(feature, setters, getters, NO);
        *appliedFlag = NO;
    } else {
        GMLog(@"APPLY_SKIP feature=%@ reason=never_applied", feature);
    }
}

void GMApplyAll(void) {
    if (gBrakeOn) {
        GMLog(@"APPLY_ALL skipped brake=1");
        return;
    }
    GMLog(@"APPLY_ALL enabled=%d grayscale=%d glare=%d garakei=%d",
          prefEnabled, prefGrayscale, prefGlare, prefGarakei);
    GMApplyOne(@"grayscale",
               @[@"setGrayscaleEnabled:", @"setGreyscaleEnabled:", @"setGrayscale:"],
               @[@"grayscaleEnabled", @"isGrayscaleEnabled", @"greyscaleEnabled"],
               prefEnabled && prefGrayscale, &gmGrayscaleApplied);
    GMApplyOne(@"reduce_white_point",
               @[@"setReduceWhitePointEnabled:", @"setReduceWhitePoint:", @"setWhitePointReductionEnabled:"],
               @[@"reduceWhitePointEnabled", @"isReduceWhitePointEnabled"],
               prefEnabled && prefGlare, &gmGlareApplied);
    // Garakei style stage-1 entry point: bold text only. Larger text
    // and home-screen layout are later stages (see README).
    GMApplyOne(@"bold_text",
               @[@"setBoldTextEnabled:", @"setBoldText:"],
               @[@"boldTextEnabled", @"isBoldTextEnabled"],
               prefEnabled && prefGarakei, &gmGarakeiApplied);
    GMLog(@"APPLY_ALL done");
}

// ---------- manager ----------
@interface GMManager ()
@property (nonatomic) BOOL setupDone;
@end

@implementation GMManager

+ (instancetype)shared {
    static GMManager *s; static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [[GMManager alloc] init]; });
    return s;
}

+ (BOOL)brakeOn { return gBrakeOn; }

- (void)reloadPrefs {
    GMLoadPrefs();
    GMLog(@"PREFS enabled=%d grayscale=%d glare=%d garakei=%d brake=%d",
          prefEnabled, prefGrayscale, prefGlare, prefGarakei, gBrakeOn);
    GMApplyAll();
}

- (void)setup {
    if (self.setupDone) return;
    self.setupDone = YES;
    @try {
        GMLog(@"SETUP_START version=%@", kGMVersion);
        [self reloadPrefs];
        GMLog(@"SETUP_DONE");
    } @catch (id e) {
        GMNoteException(@"setup", e);
    }
}

@end
