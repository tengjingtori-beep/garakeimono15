// GarakeiMono15 — core (0.1.1)
//
// 0.1.1 changes (from the 0.1.0 real-device log):
//   - The log proved AXSettings exists and answers sharedInstance,
//     but has NO setGrayscaleEnabled:/setGreyscaleEnabled:/
//     setGrayscale: (all responds=0 -> setter_not_found), while
//     setReduceWhitePointEnabled: works (CALL_OK + readback match).
//   - So 0.1.1 adds, for grayscale only: a one-time diagnostic dump
//     (METHOD_DUMP / PREF_DUMP), extra runtime-checked setter
//     candidates (colorFilter/displayFilter family), a KVC fallback,
//     and the main fix: a CAFilter "colorSaturation" (inputAmount=0)
//     applied to every SpringBoard UIWindow layer while grayscale
//     is on, removed when it goes off (FILTER_APPLY in the log).
//
// Stage 1 tries to switch iOS's own accessibility appearance
// settings (grayscale / reduce white point / bold text) from inside
// SpringBoard. Those settings live behind private Accessibility
// classes (AXSettings and friends) whose exact class, singleton and
// method names are NOT guaranteed on iOS 15.8, so nothing here is
// hard-coded on a guess:
//
//   - every candidate class / instance getter / setter / getter is
//     resolved at runtime with NSClassFromString / NSSelectorFromString,
//   - a setter is only ever called when the object really responds
//     to it (respondsToSelector:),
//   - every step (class found?, instance?, setter?, call, read-back)
//     is written to the log, so the device log itself proves which
//     names exist on this iOS and whether the call took effect.
//
// If a name does not exist, the feature simply does nothing and the
// log says why. All calls are wrapped in @try/@catch and counted by
// the failure brake: after 5 exceptions all feature activity stops
// until respring, so a broken path can never loop into Safe Mode.
// No heavy or risky initialisation lives in SpringBoard.

#import "GMManager.h"
#import <UIKit/UIKit.h>
#import <objc/message.h>
#import <objc/runtime.h>

NSString * const kGMPrefsID = @"com.tori.garakeimono15";
static NSString * const kGMVersion = @"0.1.1";

// ---------- prefs ----------
static BOOL prefEnabled = YES;
static BOOL prefGrayscale = NO;
static BOOL prefGlare = NO;
static BOOL prefGarakei = NO;

static id GMAppValue(NSString *key) {
    return (__bridge_transfer id)CFPreferencesCopyAppValue((__bridge CFStringRef)key,
                                                           (__bridge CFStringRef)kGMPrefsID);
}

void GMLoadPrefs(void) {
    @try {
        id v;
        v = GMAppValue(@"Enabled");           if (v) prefEnabled = [v boolValue];
        v = GMAppValue(@"GrayscaleEnabled");  if (v) prefGrayscale = [v boolValue];
        v = GMAppValue(@"ReduceGlareEnabled"); if (v) prefGlare = [v boolValue];
        v = GMAppValue(@"GarakeiStyleEnabled"); if (v) prefGarakei = [v boolValue];
        CFPreferencesAppSynchronize((__bridge CFStringRef)kGMPrefsID);
    } @catch (__unused id e) {}
}

// ---------- log ----------
// /var/mobile/Library/Logs/GarakeiMono15.log (fallback /var/tmp).
// The file is created ONLY when it does not exist and then appended
// to: creating it on every write from every process would truncate
// lines other processes already wrote (the Future15 0.2.x bug).
// Every line is prefixed with the process name.
static NSString *GMLogPath(void) {
    NSString *primary = @"/var/mobile/Library/Logs/GarakeiMono15.log";
    NSFileManager *fm = NSFileManager.defaultManager;
    if ([fm fileExistsAtPath:primary]) return primary;
    NSString *dir = @"/var/mobile/Library/Logs";
    if ([fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil] &&
        [fm createFileAtPath:primary contents:nil attributes:nil]) {
        return primary;
    }
    NSString *fallback = @"/var/tmp/GarakeiMono15.log";
    if (![fm fileExistsAtPath:fallback]) {
        [fm createFileAtPath:fallback contents:nil attributes:nil];
    }
    return fallback;
}

void GMLog(NSString *format, ...) {
    @try {
        va_list ap; va_start(ap, format);
        NSString *msg = [[NSString alloc] initWithFormat:format arguments:ap];
        va_end(ap);
        NSString *proc = [[NSProcessInfo processInfo] processName] ?: @"?";
        NSString *stamp = [NSDateFormatter localizedStringFromDate:[NSDate date]
                                                         dateStyle:NSDateFormatterNoStyle
                                                         timeStyle:NSDateFormatterMediumStyle];
        NSString *line = [NSString stringWithFormat:@"[%@][%@] %@\n", stamp, proc, msg];
        NSString *path = GMLogPath();
        NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:path];
        if (!fh) return;
        [fh seekToEndOfFile];
        [fh writeData:[line dataUsingEncoding:NSUTF8StringEncoding]];
        [fh synchronizeFile];
        [fh closeFile];
    } @catch (__unused id e) {}
}

// ---------- failure brake ----------
// After 5 exceptions anywhere in the manager the brake engages and
// every feature path stops until respring. It never auto-releases.
static NSInteger gExceptionCount = 0;
static BOOL gBrakeOn = NO;
static const NSInteger kGMBrakeThreshold = 5;

void GMNoteException(NSString *where, id error) {
    gExceptionCount++;
    GMLog(@"EXCEPTION %@: %@ (count=%ld)", where, error, (long)gExceptionCount);
    if (!gBrakeOn && gExceptionCount >= kGMBrakeThreshold) {
        gBrakeOn = YES;
        GMLog(@"BRAKE_ON exceptions reached %ld: all feature activity is stopped until respring", (long)gExceptionCount);
    }
}

// ---------- stage-1 apply machinery (runtime-resolved) ----------
static NSArray<NSString *> *GMClassCandidates(void) {
    return @[@"AXSettings", @"GAXSettings", @"_AXSettings", @"AXAccessibilitySettings"];
}
static NSArray<NSString *> *GMInstanceCandidates(void) {
    return @[@"sharedInstance", @"sharedSettings", @"shared", @"defaultSettings"];
}

// ---------- 0.1.1 diagnostics (grayscale, once per respring) ----------
// The 0.1.0 log proved the guessed grayscale setter names do not
// exist on AXSettings in this iOS. Before trying more names, dump
// what DOES exist: every AXSettings method whose name smells like
// grayscale / colour filters (METHOD_DUMP), and the current values
// of the Accessibility prefs domain keys that might drive the
// system colour filter (PREF_DUMP, read-only: nothing is written).
static BOOL gDiagDumped = NO;

static BOOL GMNameMatchesDiagFilter(NSString *name) {
    NSString *low = [name lowercaseString];
    for (NSString *needle in @[@"gray", @"grey", @"filter", @"color", @"mono", @"saturat"]) {
        if ([low containsString:needle]) return YES;
    }
    return NO;
}

static void GMDumpDiagnosticsOnce(void) {
    if (gDiagDumped) return;
    gDiagDumped = YES;
    GMLog(@"DIAG_DUMP_START version=%@", kGMVersion);
    @try {
        Class cls = NSClassFromString(@"AXSettings");
        GMLog(@"METHOD_DUMP class=AXSettings found=%d", cls != nil);
        if (cls) {
            unsigned int icount = 0, ccount = 0;
            Method *methods = class_copyMethodList(cls, &icount);
            NSInteger matched = 0;
            for (unsigned int i = 0; i < icount; i++) {
                NSString *name = NSStringFromSelector(method_getName(methods[i]));
                if (GMNameMatchesDiagFilter(name)) {
                    GMLog(@"METHOD_DUMP kind=instance name=%@", name);
                    matched++;
                }
            }
            if (methods) free(methods);
            Method *cmethods = class_copyMethodList(object_getClass(cls), &ccount);
            for (unsigned int i = 0; i < ccount; i++) {
                NSString *name = NSStringFromSelector(method_getName(cmethods[i]));
                if (GMNameMatchesDiagFilter(name)) {
                    GMLog(@"METHOD_DUMP kind=class name=%@", name);
                    matched++;
                }
            }
            if (cmethods) free(cmethods);
            GMLog(@"METHOD_DUMP matched=%ld scanned_instance=%u scanned_class=%u",
                  (long)matched, icount, ccount);
        }
    } @catch (id e) {
        GMNoteException(@"diag_method_dump", e);
    }
    @try {
        NSArray<NSString *> *keys = @[
            @"ColorFiltersEnabled", @"ColorFilterEnabled", @"AXColorFiltersEnabled",
            @"AXColorFilterEnabled", @"DisplayFilterEnabled", @"DisplayFiltersEnabled",
            @"AXDisplayFilterEnabled", @"GrayscaleEnabled", @"GreyscaleEnabled",
            @"AXGrayscaleEnabled", @"AXColorFilterType", @"ColorFilterType",
            @"ColorFiltersType", @"DisplayFilterType", @"AXColorFilter",
            @"ColorFilter", @"MonoEnabled", @"Grayscale"
        ];
        for (NSString *key in keys) {
            id v = (__bridge_transfer id)CFPreferencesCopyAppValue(
                (__bridge CFStringRef)key, CFSTR("com.apple.Accessibility"));
            GMLog(@"PREF_DUMP domain=com.apple.Accessibility key=%@ value=%@",
                  key, v ? [v description] : @"<nil>");
        }
    } @catch (id e) {
        GMNoteException(@"diag_pref_dump", e);
    }
    GMLog(@"DIAG_DUMP_DONE");
}

// KVC fallback for one boolean setting on an already-resolved
// instance. Undefined keys raise NSUndefinedKeyException, which is
// caught per key; a key only counts when it accepts the write AND
// reads back as the desired value.
static BOOL GMApplyViaKVC(id instance, NSString *feature,
                          NSArray<NSString *> *keys, BOOL desired) {
    for (NSString *key in keys) {
        @try {
            [instance setValue:@(desired) forKey:key];
            id back = nil;
            @try { back = [instance valueForKey:key]; } @catch (__unused id e2) {}
            BOOL ok = back && [back respondsToSelector:@selector(boolValue)] && [back boolValue] == desired;
            GMLog(@"KVC_TRY feature=%@ key=%@ readback=%@ ok=%d",
                  feature, key, back ? [back description] : @"<nil>", ok);
            if (ok) return YES;
        } @catch (id e) {
            GMLog(@"KVC_TRY feature=%@ key=%@ exception=%@", feature, key, [e description]);
        }
    }
    return NO;
}

// Tries one boolean accessibility setting. Returns YES when a
// setter (or the KVC fallback) was actually called; the log carries
// the whole story (APPLY_START -> CLASS/INSTANCE/SETTER ->
// CALL/READBACK -> APPLY_RESULT).
static BOOL GMApplyBoolFeature(NSString *feature,
                               NSArray<NSString *> *setterNames,
                               NSArray<NSString *> *getterNames,
                               NSArray<NSString *> *kvcKeys,
                               BOOL desired) {
    GMLog(@"APPLY_START feature=%@ desired=%d", feature, desired);
    @try {
        Class cls = nil;
        NSString *clsName = nil;
        for (NSString *name in GMClassCandidates()) {
            Class c = NSClassFromString(name);
            GMLog(@"CLASS name=%@ found=%d", name, c != nil);
            if (c) { cls = c; clsName = name; break; }
        }
        if (!cls) {
            GMLog(@"APPLY_RESULT feature=%@ result=class_not_found", feature);
            return NO;
        }

        id instance = nil;
        NSString *instHow = nil;
        for (NSString *name in GMInstanceCandidates()) {
            SEL sel = NSSelectorFromString(name);
            if ([cls respondsToSelector:sel]) {
                @try {
                    instance = ((id (*)(id, SEL))objc_msgSend)((id)cls, sel);
                } @catch (__unused id e) { instance = nil; }
                GMLog(@"INSTANCE via=%@ ok=%d", name, instance != nil);
                if (instance) { instHow = name; break; }
            } else {
                GMLog(@"INSTANCE via=%@ missing=1", name);
            }
        }
        if (!instance) {
            @try {
                instance = [[cls alloc] init];
                instHow = @"alloc_init";
            } @catch (__unused id e) { instance = nil; }
            GMLog(@"INSTANCE via=alloc_init ok=%d", instance != nil);
        }
        if (!instance) {
            GMLog(@"APPLY_RESULT feature=%@ result=no_instance class=%@", feature, clsName);
            return NO;
        }

        SEL setter = NULL;
        NSString *setterName = nil;
        for (NSString *name in setterNames) {
            SEL sel = NSSelectorFromString(name);
            BOOL ok = [instance respondsToSelector:sel];
            GMLog(@"SETTER name=%@ responds=%d", name, ok);
            if (ok) { setter = sel; setterName = name; break; }
        }
        if (!setter) {
            // 0.1.1: before giving up, try the KVC route on the same
            // instance (grayscale passes candidate keys; others nil).
            if (kvcKeys.count && GMApplyViaKVC(instance, feature, kvcKeys, desired)) {
                GMLog(@"APPLY_RESULT feature=%@ result=kvc_called class=%@ instance=%@", feature, clsName, instHow);
                return YES;
            }
            GMLog(@"APPLY_RESULT feature=%@ result=setter_not_found class=%@ instance=%@", feature, clsName, instHow);
            return NO;
        }

        ((void (*)(id, SEL, BOOL))objc_msgSend)(instance, setter, desired);
        GMLog(@"CALL_OK feature=%@ setter=%@ value=%d", feature, setterName, desired);

        NSString *readback = @"unavailable";
        for (NSString *name in getterNames) {
            SEL sel = NSSelectorFromString(name);
            if ([instance respondsToSelector:sel]) {
                BOOL val = ((BOOL (*)(id, SEL))objc_msgSend)(instance, sel);
                readback = [NSString stringWithFormat:@"%@=%d", name, val];
                break;
            }
        }
        GMLog(@"READBACK feature=%@ %@", feature, readback);
        GMLog(@"APPLY_RESULT feature=%@ result=called setter=%@ readback=%@", feature, setterName, readback);
        return YES;
    } @catch (id e) {
        GMNoteException([NSString stringWithFormat:@"apply:%@", feature], e);
        GMLog(@"APPLY_RESULT feature=%@ result=exception", feature);
        return NO;
    }
}

// ---------- 0.1.1 main fix: CAFilter on SpringBoard windows ----------
// While grayscale is on, every UIWindow in SpringBoard gets a
// CAFilter of type "colorSaturation" with inputAmount 0.0 on its
// layer, which renders the window in pure black and white without
// any accessibility setting at all. CAFilter is a private class:
// it is resolved with NSClassFromString at runtime and only used
// when it really answers filterWithType:. Window layers only —
// never per-view — so the cost stays at one filter per window.
// Off removes the filters again. FILTER_APPLY lines record whether
// the filter type was accepted and how many windows were covered.
static BOOL gmFilterApplied = NO;

static void GMApplyWindowFilter(BOOL on) {
    @try {
        Class fcls = NSClassFromString(@"CAFilter");
        if (!fcls) {
            GMLog(@"FILTER_APPLY result=cafilter_class_not_found on=%d", on);
            return;
        }
        if (on && ![fcls respondsToSelector:@selector(filterWithType:)]) {
            GMLog(@"FILTER_APPLY result=filterWithType_missing on=%d", on);
            return;
        }
        NSArray *windows = nil;
        @try {
            // UIApplication.windows is deprecated in iOS 15 and -Werror
            // turns that into a build failure, so collect the windows
            // from the connected window scenes instead.
            NSMutableArray *collected = [NSMutableArray array];
            for (UIScene *scene in [[UIApplication sharedApplication] connectedScenes]) {
                if ([scene isKindOfClass:[UIWindowScene class]]) {
                    [collected addObjectsFromArray:((UIWindowScene *)scene).windows];
                }
            }
            windows = collected;
        } @catch (__unused id e) {}
        NSInteger total = 0, applied = 0;
        NSString *typeSeen = nil;
        for (UIWindow *w in windows) {
            if (![w isKindOfClass:[UIWindow class]]) continue;
            total++;
            @try {
                if (on) {
                    id filter = ((id (*)(id, SEL, id))objc_msgSend)((id)fcls,
                        @selector(filterWithType:), @"colorSaturation");
                    if (!filter) continue;
                    [filter setValue:@(0.0) forKey:@"inputAmount"];
                    @try { typeSeen = [filter valueForKey:@"type"]; } @catch (__unused id e) {}
                    w.layer.filters = @[filter];
                    // Read back: the layer must now report our filter.
                    if (w.layer.filters.count == 1) applied++;
                } else {
                    if (w.layer.filters.count) w.layer.filters = nil;
                    if (w.layer.filters.count == 0) applied++;
                }
            } @catch (id e) {
                GMLog(@"FILTER_APPLY window_exception=%@", [e description]);
            }
        }
        gmFilterApplied = on && applied > 0;
        GMLog(@"FILTER_APPLY result=%@ on=%d windows=%ld applied=%ld filterType=%@",
              (total > 0 && applied == total) ? @"ok" : (applied > 0 ? @"partial" : @"no_windows"),
              on, (long)total, (long)applied, typeSeen ?: @"n/a");
    } @catch (id e) {
        GMNoteException(@"window_filter", e);
        GMLog(@"FILTER_APPLY result=exception on=%d", on);
    }
}

// Tracks what this process actually switched on, so an OFF is only
// sent for something we turned on (never touching settings the user
// set by hand in the Accessibility menu).
static BOOL gmGrayscaleApplied = NO;
static BOOL gmGlareApplied = NO;
static BOOL gmGarakeiApplied = NO;

static void GMApplyOne(NSString *feature,
                       NSArray<NSString *> *setters,
                       NSArray<NSString *> *getters,
                       NSArray<NSString *> *kvcKeys,
                       BOOL wantOn, BOOL *appliedFlag) {
    if (wantOn) {
        GMApplyBoolFeature(feature, setters, getters, kvcKeys, YES);
        *appliedFlag = YES;
    } else if (*appliedFlag) {
        GMApplyBoolFeature(feature, setters, getters, kvcKeys, NO);
        *appliedFlag = NO;
    } else {
        GMLog(@"APPLY_SKIP feature=%@ reason=never_applied", feature);
    }
}

void GMApplyAll(void) {
    if (gBrakeOn) {
        GMLog(@"APPLY_ALL skipped brake=1");
        return;
    }
    GMLog(@"APPLY_ALL enabled=%d grayscale=%d glare=%d garakei=%d",
          prefEnabled, prefGrayscale, prefGlare, prefGarakei);
    BOOL wantGray = prefEnabled && prefGrayscale;
    // 0.1.1 diagnostics run exactly once, the first time grayscale
    // is switched on, before the new routes are tried.
    if (wantGray) GMDumpDiagnosticsOnce();
    GMApplyOne(@"grayscale",
               @[@"setGrayscaleEnabled:", @"setGreyscaleEnabled:", @"setGrayscale:",
                 @"setColorFilterEnabled:", @"setColorFiltersEnabled:",
                 @"setDisplayFilterEnabled:", @"setDisplayFiltersEnabled:",
                 @"setColorFilter:", @"setDisplayFilter:"],
               @[@"grayscaleEnabled", @"isGrayscaleEnabled", @"greyscaleEnabled",
                 @"colorFilterEnabled", @"isColorFilterEnabled",
                 @"colorFiltersEnabled", @"displayFilterEnabled",
                 @"isDisplayFilterEnabled"],
               @[@"grayscaleEnabled", @"colorFilterEnabled", @"displayFilterEnabled",
                 @"colorFiltersEnabled", @"displayFiltersEnabled"],
               wantGray, &gmGrayscaleApplied);
    // 0.1.1 main fix: the SpringBoard window filter does not depend
    // on any accessibility entry point. On while grayscale is on,
    // off again as soon as it (or the master switch) goes off.
    if (wantGray) {
        GMApplyWindowFilter(YES);
    } else if (gmFilterApplied) {
        GMApplyWindowFilter(NO);
    }
    GMApplyOne(@"reduce_white_point",
               @[@"setReduceWhitePointEnabled:", @"setReduceWhitePoint:", @"setWhitePointReductionEnabled:"],
               @[@"reduceWhitePointEnabled", @"isReduceWhitePointEnabled"],
               nil,
               prefEnabled && prefGlare, &gmGlareApplied);
    // Garakei style stage-1 entry point: bold text only. Larger text
    // and home-screen layout are later stages (see README).
    GMApplyOne(@"bold_text",
               @[@"setBoldTextEnabled:", @"setBoldText:"],
               @[@"boldTextEnabled", @"isBoldTextEnabled"],
               nil,
               prefEnabled && prefGarakei, &gmGarakeiApplied);
    GMLog(@"APPLY_ALL done");
}

// ---------- manager ----------
@interface GMManager ()
@property (nonatomic) BOOL setupDone;
@end

@implementation GMManager

+ (instancetype)shared {
    static GMManager *s; static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [[GMManager alloc] init]; });
    return s;
}

+ (BOOL)brakeOn { return gBrakeOn; }

- (void)reloadPrefs {
    GMLoadPrefs();
    GMLog(@"PREFS enabled=%d grayscale=%d glare=%d garakei=%d brake=%d",
          prefEnabled, prefGrayscale, prefGlare, prefGarakei, gBrakeOn);
    GMApplyAll();
}

- (void)setup {
    if (self.setupDone) return;
    self.setupDone = YES;
    @try {
        GMLog(@"SETUP_START version=%@", kGMVersion);
        [self reloadPrefs];
        GMLog(@"SETUP_DONE");
        // Windows can still appear after launch finishes; re-run the
        // apply once a few seconds later so late windows also get the
        // grayscale filter (GMApplyAll is idempotent for the setters
        // and simply re-sets the same window filters).
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(4.0 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            if (!gBrakeOn && prefEnabled && prefGrayscale) {
                GMLog(@"APPLY_ALL reason=post_launch_reapply");
                GMApplyAll();
            }
        });
    } @catch (id e) {
        GMNoteException(@"setup", e);
    }
}

@end
