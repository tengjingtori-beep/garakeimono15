#import "GMPrefsListController.h"
#import <UIKit/UIKit.h>
#import <Preferences/PSSpecifier.h>

// Settings pane for GarakeiMono15.
// Switches are plain PSSwitchCell rows and every action is a plain
// PSButtonCell row. No PSLinkListCell / PSListItemsController choice
// UI anywhere: on this iPhone 7 (iOS 15) that control either ignores
// taps or crashes the Settings app (proven by VoiceChat15/Future15).
@implementation GMPrefsListController

- (NSArray *)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    }
    return _specifiers;
}

// Ask SpringBoard (where the tweak dylib lives) to reload the prefs
// and re-apply the look right now, without waiting for a respring.
- (void)applyNow:(id)sender {
    (void)sender;
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                         CFSTR("com.tori.garakeimono15.changed"),
                                         NULL, NULL, true);
}

// The tweak (SpringBoard, same mobile user) owns the log file, and
// the Settings app also runs as mobile, so it can read it directly.
- (void)showLog:(id)sender {
    (void)sender;
    NSString *text = nil;
    for (NSString *path in @[@"/var/mobile/Library/Logs/GarakeiMono15.log",
                             @"/var/tmp/GarakeiMono15.log"]) {
        text = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
        if (text) break;
    }
    if (!text.length) {
        text = @"ログはまだありません。リスプリングした後で、もう一度開いてください。";
    } else if (text.length > 3000) {
        text = [text substringFromIndex:text.length - 3000];
    }
    UIAlertController *alert =
        [UIAlertController alertControllerWithTitle:@"GarakeiMono15 ログ（最後の部分）"
                                            message:text
                                     preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"閉じる"
                                              style:UIAlertActionStyleDefault
                                            handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)clearLog:(id)sender {
    (void)sender;
    for (NSString *path in @[@"/var/mobile/Library/Logs/GarakeiMono15.log",
                             @"/var/tmp/GarakeiMono15.log"]) {
        [NSFileManager.defaultManager removeItemAtPath:path error:nil];
    }
}

@end
