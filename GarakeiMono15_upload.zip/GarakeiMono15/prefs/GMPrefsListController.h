#import <Preferences/PSListController.h>

@interface GMPrefsListController : PSListController
@end
